// Fill out your copyright notice in the Description page of Project Settings.


#include "UIController.h"

AUIController::AUIController()
{
	bShowMouseCursor = true;
	bEnableClickEvents = true;
	//bEnableTouchEvents = true;
	bEnableMouseOverEvents = true;
	//bEnableTouchOverEvents = true;
}
