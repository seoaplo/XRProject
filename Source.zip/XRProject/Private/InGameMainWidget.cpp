#include "InGameMainWidget.h"

UInGameMainWidget::UInGameMainWidget(const FObjectInitializer& ObjectInitializer) : UUserWidget(ObjectInitializer)
{
	bIsVisible = true;
}