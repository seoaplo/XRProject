// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CharacterStatComponent.h"
#include "EnermyStatComponent.generated.h"

/**
 * 
 */
UCLASS()
class XRPROJECT_API UEnermyStatComponent : public UCharacterStatComponent
{
	GENERATED_BODY()
	

public:
protected:
private:

};
