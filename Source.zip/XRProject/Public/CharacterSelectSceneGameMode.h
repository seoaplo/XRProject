// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include <vector>
#include <string>
#include "PlayerCharacter.h"
#include "CharacterSelectWidget.h"
#include "CoreMinimal.h"
#include "XRGameInstance.h"
#include "Camera/CameraActor.h"
#include "XRProjectGameModeBase.h"
#include "CharacterSelectSceneGameMode.generated.h"


struct FCharacterSelectInfo
{
public:
	std::wstring Name;
	int32 Level;
	int32 Str;
	int32 Dex;
	int32 Int;
	int32 Job;
	int32 Face;
	int32 Hair;
	int32 Gold;
	int32 Zone;
	float x, y, z;
	int32 armor_itemid;
	int32 hand_itemid;
	int32 shoes_itemid;;
	int32 weapon_itemid;
	int32 gender;
};

/**
 * 
 */
UCLASS()
class XRPROJECT_API ACharacterSelectSceneGameMode : public AXRProjectGameModeBase
{
	GENERATED_BODY()
public:
	ACharacterSelectSceneGameMode();
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "C_GameMode")
		TSubclassOf<UCharacterSelectWidget> LoginWidget;
	UPROPERTY()
		UCharacterSelectWidget* CurrentWidget;

public:
	std::vector<APlayerCharacter*> CharacterList; // ���� ������ ������ ĳ������ ����Ʈ(��Ŷ���� �޾ƿ;� �Ѵ�.)
	
public:
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "C_Camera")
		ACameraActor* MainCamera;
private:

	FVector MainCameraLocation;
	FVector CharacterActorLocation;
	class UDataTable* PartsDataTable; //Hair, Face ���������̺�
public:
	int64 BeforeSlotNumber;
public:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;
public:
	void ChangeSelectedCharacter(int64 SlotNumber);
	void HandleCharacterCreateFail(class InputStream& input);
	void HandleCharacterList(class InputStream& input);
	void HandleMigrateZone(class InputStream& input);
	void HandleCharacterCreate(class InputStream& input);
	void HandleCharacterDelete(class InputStream& input);
	void SendConfirmRequest();
	void CreatePlayerCharacter(APlayerCharacter* Character, FCharacterSelectInfo& Info);
	void LoadPartsComplete(FSoftObjectPath AssetPath, EPartsType Type, APlayerCharacter* Character);
};