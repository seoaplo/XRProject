#include "SlotObject.h"

UTexture2D * USlotObject::GetIcon()
{
	return nullptr;
}

int USlotObject::GetCount()
{
	return 0;
}
